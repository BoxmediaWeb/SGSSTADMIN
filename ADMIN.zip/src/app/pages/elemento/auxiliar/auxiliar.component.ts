import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auxiliar',
  templateUrl: './auxiliar.component.html',
  styleUrls: ['./auxiliar.component.scss']
})
export class AuxiliarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
