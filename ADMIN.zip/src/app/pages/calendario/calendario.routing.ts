import { Route } from '@angular/router';
import { CalendarioComponent } from './calendario.component';

export const CalendarioRoutes: Route[] = [
    {
        path     : '',
        component: CalendarioComponent,
    }
];