import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pesv',
  templateUrl: './pesv.component.html',
  styleUrls: ['./pesv.component.scss']
})
export class PesvComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
